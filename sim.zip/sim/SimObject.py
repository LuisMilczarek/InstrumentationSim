
import numpy as np
import pygame as pg

from .SimBase import SimBase

class SimObject(SimBase):
    def __init__(self, parent : SimBase, screen) -> None:
        self.__parent = parent
        self.__pose = np.matrix([0,0,0])
        self.screen = screen
    
    def parent(self) -> SimBase:
        return self.__parent

    @property
    def pose(self) -> np.matrix:

        return self.__pose
    
    @pose.setter
    def pose(self, pose : np.matrix):
        self.__pose = np.matrix(pose)
    
    @property
    def matrix(self) -> np.matrix:
        matrix = np.matrix([[np.cos(self.pose[0,2]), -np.sin(self.pose[0,2]), self.pose[0,0]],
                             [np.sin(self.pose[0,2]),   np.cos(self.pose[0,2]), self.pose[0,1]],
                                                 [0,                        0,             1]])
        return self.__parent.matrix * matrix

    def draw(self):
        raise NotImplementedError