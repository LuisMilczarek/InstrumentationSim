import numpy as np

class SimBase(object):
    def __init__(self) -> None:
        pass

    @property
    def matrix(self) -> np.matrix:
        raise NotImplementedError