from sim import SimObject
from sim.SimBase import SimBase

import pygame as pg

import numpy as np

class Circle(SimObject):
    def __init__(self, parent: SimBase, screen, radius) -> None:
        super().__init__(parent, screen)
        self.__radius = radius
    
    def draw(self):
        pose = self.pose[0]
        pose[0,2] = 1     
        globalPose = self.parent().matrix * pose.transpose()
        globalPose = pg.Vector2(globalPose[0], globalPose[1])
        pg.draw.circle(self.screen, "red", globalPose, self.__radius)